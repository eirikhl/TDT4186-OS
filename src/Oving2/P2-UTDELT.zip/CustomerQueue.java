/**
 * This class implements a queue of customers as a circular buffer.
 */
public class CustomerQueue {
	/**
	 * Creates a new customer queue. Make sure to save these variables in the class.
	 * @param queueLength	The maximum length of the queue.
	 * @param gui			A reference to the GUI interface.
	 */
    public CustomerQueue(int queueLength, Gui gui) {
		// Incomplete
	}

	public void add(Customer customer) {
		// Inclomplete
	}

	public Customer next() {
		// Inclomplete
		return null;
	}

	// Add more methods as needed
}
